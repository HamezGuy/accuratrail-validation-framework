# Vendored standard

The generated USDM types and schema derive from CDISC DDF-RA release v4.0.0,
`Deliverables/API/USDM_API.json`, copyright (c) 2022 CDISC.

The exact pinned release distributes an MIT license, retained in
`standards/cdisc-usdm/4.0.0/LICENSE`. The manifest records source URLs and SHA-256
hashes. Do not substitute the license or artifacts from a moving main branch.

The generator and validator dependencies retain their respective package licenses.

The pinned USDM controlled-terminology workbook, CORE rule specification workbook
and XMI logical model are from the same DDF-RA v4.0.0 release. The extracted reference
metadata preserves their source hashes and is generated without changing the originals.

Official executable rules are pinned to cdisc-open-rules commit
`1fb7b81e40bdb6632375761c561fabd29676a477`; runtime resources and terminology caches
are from cdisc-rules-engine v0.17.1. Their MIT licenses are retained as
`standards/cdisc-usdm/4.0.0/core/LICENSE.rules` and `LICENSE.engine`. Primitive cache
data is converted to JSON without permitting executable pickle globals. The CORE
manifest records every shipped artifact checksum. Published test fixtures are
downloaded into a separate test cache, not included in the runtime package.

CDISC Terminology was originally published by the National Cancer Institute:
https://www.cancer.gov/about-nci/organization/cbiit/vocabulary/cdisc . The exact
terminology packages used here are recorded in the CORE manifest; terms remain
attributed to CDISC/NCI and retain their original definitions and identifiers.
The js-yaml 4.3.2 override updates the generator's pinned transitive 4.3.1 dependency
to address GHSA-2883-xcg3-v3hh; it does not change the checked-in JSON source.

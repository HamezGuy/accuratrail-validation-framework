# @accura-trial/shared-types

Canonical TypeScript DTO contracts shared by the AccuraTrial EDC API, Angular
EDC, and protocol connector.

## Release contract

Consumers install this repository over HTTPS and pin a full Git commit SHA.
Branch names and mutable tags are not valid production dependencies.

Before updating a consumer pin:

```bash
npm ci
npm run typecheck
npm run build
npm pack --dry-run
```

The Git dependency `prepare` script builds `dist` during installation. Keep
TypeScript in `devDependencies` and keep `files: ["dist"]` so a future package
registry release has the same public artifact. The non-git
`C:\Projects\EDCProject\shared-types` directory is a local compatibility mirror,
not a production source of truth.

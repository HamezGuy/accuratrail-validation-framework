# @accura-trial/shared-types

Canonical TypeScript DTO contracts shared by the AccuraTrial EDC API, the Angular
EDC and the other estate consumers (Intelligence Layer, Command Center, the
semantic layer, the protocol connector, interop middleware and the validation
framework).

## Release contract

Consumers never install this repository from Git or a registry. Each consumer
vendors an immutable, content-hashed tarball with its receipt and pins it with a
`file:vendor/...` dependency, so a build needs no network access and no token.

1. Build and check the release in this repository:

   ```bash
   npm ci
   npm run typecheck
   npm test
   npm run pack:study-contracts -- <output directory>
   ```

   `pack:study-contracts` rebuilds `dist`, writes `release-manifest.json`
   (`edc-study-contract-release/1`, with the source and runtime tree hashes) and
   produces `accura-trial-shared-types-0.2.0.<sha16>.tgz`, named by the first 16
   hex digits of its SHA-256, plus `<tgz>.json` (`edc-study-contract-package/1`:
   byte length, SHA-256, npm `integrity`, source tree, runtime tree and manifest
   hashes). It never publishes or pushes. An existing file of the same name must
   hold the same bytes.

2. In each consumer: copy both files into `vendor/`, set
   `"@accura-trial/shared-types": "file:vendor/<tgz>"` in `package.json`, and run
   `npm install` so `package-lock.json` records the same `integrity` as the
   receipt. Keep the earlier tarballs in `vendor/`; a rollback is a one-line
   change. Commit the tarball, its receipt, `package.json` and the lockfile
   together, and name the source commit and tarball in the commit message.

3. Re-vendor the producer before its consumers for a contract change: the EDC API
   first, then the Angular EDC and the other consumers.

The EDC frontend's portable form presentation release records a hash of the host
lockfile, so re-vendoring this package there also means repacking
`packages/form-presentation` (`npm --prefix packages/form-presentation run
pack:portable -- <dir>`) and vendoring that tarball; its
`pack.mjs --verify-installed` check fails otherwise.

`node scripts/report-consumer-pins.cjs` lists which build each consumer under
`C:\Projects` vendors, with its receipt, so divergence is visible before a
contract change. It only reads.

Keep TypeScript in `devDependencies` and `files` limited to `dist`, `standards`,
`release-manifest.json` and `THIRD-PARTY-NOTICES.md`. The generated
`release-manifest.json` is not committed. The non-git
`C:\Projects\EDCProject\shared-types` directory is a local compatibility mirror,
not a production source of truth.
